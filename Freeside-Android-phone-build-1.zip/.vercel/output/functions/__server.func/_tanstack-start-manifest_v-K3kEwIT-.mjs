//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-K3kEwIT-.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/api/chat"],
		preloads: ["/assets/index-DMm3507c.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DMm3507c.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-B0Vz6EqS.js"]
	}
} });
//#endregion
export { tsrStartManifest };
